package com.example.assignment1draft1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class Controller2 {
    @FXML
    public ColorPicker colorPicker;

    @FXML
    TextField textField;

    @FXML
    TextField dim;

    @FXML
    public ListView<DisplayTray> lv;


    public void addDisplayTray(ActionEvent actionEvent)
    {
        String id =textField.getText();
        String cp = String.valueOf(colorPicker.getValue());
        double dimen = Double.parseDouble(dim.getText());

        DisplayTray dt = new DisplayTray(id,cp,dimen);

        Main.myDisplayTrays.addElement(dt);

        System.out.println(Main.myDisplayTrays.gethead());
        populateListView();
    }
    public void populateListView(){
        lv.getItems().clear();
        Main.myDisplayTrays.addContentstoListView(lv);
    }
}
