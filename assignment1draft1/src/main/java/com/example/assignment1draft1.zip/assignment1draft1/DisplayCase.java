package com.example.assignment1draft1;

import java.util.ArrayList;

public class DisplayCase {
    private int displayCaseNumber = 1;
    private boolean displayCaseType = false;
    private boolean displayCaseLighting = false;
    public LinkList<DisplayTray> displayTrays = new LinkList<>();
   // public DisplayCase() {
   //     displayCases = new LinkList<DisplayCase>();
  //  }
    public LinkList<DisplayTray> getDisplayTrays() {
        return displayTrays;
    }

    public void setDisplayTrays(LinkList<DisplayTray> displayTrays) {
        this.displayTrays = displayTrays;
    }

    public DisplayCase(int displayCaseNumber, boolean displayCaseType, boolean displayCaseLighting) {
        this.displayCaseNumber = displayCaseNumber;
        this.displayCaseType = displayCaseType;
        this.displayCaseLighting = displayCaseLighting;
    }

    @Override
    public String toString() {
        return "DisplayCase{" +
                "displayCaseNumber=" + displayCaseNumber +
                ", displayCaseType=" + displayCaseType +
                ", displayCaseLighting=" + displayCaseLighting +
             //   ", displayTrays=" + displayTrays +
                '}';
    }

   // public String add(DisplayTray displayTray){return displayTrays.addElement(displayTray );}

    //    public DisplayCase(int displayCaseNumber, boolean displayCaseType, boolean displayCaseLighting){
//        setDisplayCaseNumber(displayCaseNumber);
//        setDisplayCaseType(displayCaseType);
//        setDisplayCaseLighting(displayCaseLighting);
//    }

//    displayCases

    public int getDisplayCaseNumber(){return displayCaseNumber;}

    public boolean isDisplayCaseType() {
        return displayCaseType;
    }

    public boolean isDisplayCaseLighting() {
        return displayCaseLighting;
    }

    public void setDisplayCaseNumber(int displayCaseNumber) {
        this.displayCaseNumber = displayCaseNumber;
    }

    public void setDisplayCaseType(boolean displayCaseType) {
        this.displayCaseType = displayCaseType;
    }

    public void setDisplayCaseLighting(boolean displayCaseLighting) {
        this.displayCaseLighting = displayCaseLighting;
    }



    // public DisplayCase next=null;

   // DisplayCase head = null;

   // DisplayCase temp=head;

   // while(temp!=null) {
    //    temp=temp.next;
    }

