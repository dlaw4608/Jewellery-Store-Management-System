package com.example.assignment1draft1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class Controller {

    @FXML
    public CheckBox lighttype ;
    @FXML
    TextField txtid, dlindex;
    @FXML
    public ChoiceBox<String> walltype;
    @FXML
    public ListView<DisplayCase> listview;



    public void addDisplayCase(ActionEvent actionEvent) {
        int id = Integer.parseInt(txtid.getText());
        boolean lighting = lighttype.isSelected();
        boolean type = false;
        if(walltype.getValue().equals("Wall-Mounted"))
            type=true;
       // String view = String.valueOf(displayview.getItems());

       //String typestr = (String) walltype.getSelectionModel().getSelectedItem();
       // int wall = 0;
       // int stand = 1;

      //  if (wall == (0)){

       // }





        DisplayCase dc = new DisplayCase(id,type  , lighting);

        Main.myDisplayCases.addElement(dc);

        System.out.println(Main.myDisplayCases.gethead());
        populateListView();

    }

    public void addDisplayTray(ActionEvent actionEvent)
    {

    }
    public void initialize(){
        walltype.getItems().addAll("Wall-Mounted","Freestanding");
        // .dispplayCaselist.populateComboBox(caseBox);


    }
public void populateListView(){
        listview.getItems().clear();
        Main.myDisplayCases.addContentstoListView(listview);
}
    public void onDelete(){
        int index = Integer.parseInt(dlindex.getText());
        Main.myDisplayCases.deleteElement(index);
        System.out.println(Main.myDisplayCases.gethead());

    }

    /*public selectIndex(){

    }
    */



   /* @FXML
    protected void onHelloButtonClick()
    {
        welcomeText.setText("Welcome to JavaFX Application!");
        DisplayCase dc = new DisplayCase(1, true, false);
        HelloApplication.myDisplayCases.addElement(dc);
        System.out.println(HelloApplication.myDisplayCases.gethead());
    }*/
}