package com.example.assignment1draft1;

public class DisplayTray {
    public LinkList<String> displayJewellery = new LinkList<>();
    public String identifier = null;
    public String materialColor = null;
    public double dimensions = 0;

    public DisplayTray(String identifier,String materialColor,double dimensions) {
        this.identifier = identifier;
        this.materialColor = materialColor;
        this.dimensions = dimensions;

    }

    public LinkList<String> getDisplayJewellery() {
        return displayJewellery;
    }

    public void setDisplayJewellery(LinkList<String> displayJewellery) {
        this.displayJewellery = displayJewellery;
    }

    @Override
    public String toString() {
        return "DisplayTray{" +
                //"displayJewellery=" + displayJewellery +
                ", identifier='" + identifier + '\'' +
                ", materialColor='" + materialColor + '\'' +
                ", dimensions=" + dimensions +
                '}';
    }
}
