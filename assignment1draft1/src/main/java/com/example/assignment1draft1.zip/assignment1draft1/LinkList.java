package com.example.assignment1draft1;

import javafx.scene.control.ListView;

import java.util.Iterator;
import java.util.ListIterator;

public class LinkList<D> implements Iterable<D> {
    public LinkNode<D> head = null; //Custom link list
   // public D contents;
  //  public D getContents() {return contents;}
  //  public void setContents(D e) {contents=e;}

    public String addElement(D e){     //adding elements of array list
        LinkNode<D> newnode =new LinkNode<>();
        newnode.setContents(e);
        newnode.next=head;
        head=newnode;
        return null;
    }

    public Boolean deleteElement(int index){
        if(index == 0)
            head = head.next;
        else{
            int counter =0;
            LinkNode<D> temp = head;
            while(counter < index -1)
            {
                temp=temp.next;
            }
            temp.next = temp.next.next;
        }
        return true;
    }

   /* public String updateElement(D e){

    }*/


  /*  public String deleteElement(D e){
        LinkNode<D> currentn = head.next;
        LinkNode<D> previousn = head;
        LinkNode<D> newnode = new LinkNode<>();
        newnode.setContents(e);
        boolean deleted = false;

        while(currentn!=null&&deleted == false){
            if(currentn.data.equals(e)){
                previousn.next = currentn.next;
                this.count--;
                deleted = true;

        }


    }*/

    public void addContentstoListView(ListView lv){
        LinkNode<D> temp=head;
        while(temp != null){
            lv.getItems().add(temp.getContents());
            temp=temp.next;
        }
    }
    public D gethead(){
        return head.getContents();
    }


  // public String deleteElement(D e){

       // fn.next=remove(head);
  // }

    @Override
    public Iterator<D> iterator() {
        return new ListIterator<D>() {

            @Override
            public boolean hasNext() {
                return false;
            }

            @Override
            public D next() {
                return null;
            }

            @Override
            public boolean hasPrevious() {
                return false;
            }

            @Override
            public D previous() {
                return null;
            }

            @Override
            public int nextIndex() {
                return 0;
            }

            @Override
            public int previousIndex() {
                return 0;
            }

            @Override
            public void remove() {

            }

            @Override
            public void set(D d) {

            }

            @Override
            public void add(D d) {

            }
        };
    }

    /*public String searchElement(D e){


    }*/

   // public LinkList<String> displayCases = new LinkList<>();
   // displayCases.





}
